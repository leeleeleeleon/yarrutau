찬사(chanshasha)
추천음역대:C3~C6

cv.이레온
그림:가온누리(@0916psy)
원음설정: EX3님

성적/혐오적/정치적 콘텐츠에 사용금지

문의:@leonmo4_gore

cv. leeleon
Picture: Gaonnuri(@0916psy)
Original sound setting: EX3

Do not use it for sexual/hate/political content
