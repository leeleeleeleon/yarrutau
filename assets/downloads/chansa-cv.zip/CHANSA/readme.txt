﻿찬사(chansa) 단독음(CV)

cv.이레온
원음설정: EX3님

사용 규약: https://leeleeleeleon.github.io/yarrutau/chansa.html#cv

문의:yarrutau67@gmail.com
