﻿어린이찬사 — 일본어 연속음(VCV) 음원

- 녹음: RecStar (reclist-jpnVCV-kor)
- 보정: 직류 제거, 60Hz 이하 제거, 깨짐(클리핑) 복원, 파일별 크기 맞춤 (보정기록.txt)
- 원음설정: EX3님
- 별칭: "- か"(시작), "a か"(연속), "a R"(끝), あ~ん(긴 모음), 息/br(숨소리)
- 기본 음소화기: JapaneseVCVPhonemizer
- 목소리 변조: B3_꼬마_숨적게 {'semi': 7, 'alpha': 1.28, 'breath': 1.4, 'bright': 2}
